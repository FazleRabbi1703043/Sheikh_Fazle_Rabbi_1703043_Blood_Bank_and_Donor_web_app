<?php
error_reporting(0);
include('includes/config.php');
if(isset($_POST['submit']))
  {

$fullname=$_POST['fullname'];

$mobile=$_POST['mobileno'];
$email=$_POST['emailid'];
$age=$_POST['age'];

$gender=$_POST['gender'];
$blodgroup=$_POST['bloodgroup'];
$address=$_POST['address'];
$message=$_POST['message'];

$status=1;

$sql="INSERT INTO tblblooddonars(FullName,MobileNumber,EmailId,Age,Gender,BloodGroup,Address,Message,status) VALUES(:fullname,:mobile,:email,:age,:gender,:blodgroup,:address,:message,:status)";
$inquiry = $dbh->prepare($sql);
$inquiry >bindParam(':fullname',$fullname,PDO::PARAM_STR);
$inquiry >bindParam(':mobile',$mobile,PDO::PARAM_STR);
$inquiry >bindParam(':email',$email,PDO::PARAM_STR);

$inquiry >bindParam(':age',$age,PDO::PARAM_STR);
$inquiry >bindParam(':gender',$gender,PDO::PARAM_STR);
$inquiry >bindParam(':blodgroup',$blodgroup,PDO::PARAM_STR);
$inquiry >bindParam(':address',$address,PDO::PARAM_STR);
$inquiry >bindParam(':message',$message,PDO::PARAM_STR);
$inquiry >bindParam(':status',$status,PDO::PARAM_STR);
$inquiry >execute();
$lastInsertId = $dbh->lastInsertId();
   if($lastInsertId)
{
$msg="Welcome!!! Your information submitted effectively";
}
else

{

$error="Something turned out badly. If it's not too much trouble, attempt once more";
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, starting scale=1, shrivel to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Blood Bank and Donor Management System | Become A Donar</title>
    <interface href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <interface href="vendor/text style wonderful/css/text style awesome.min.css" rel="stylesheet" type="text/css">
    <interface href="css/present day business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-file: 1;
    }

    @media (max-width: 576px) {
        nav > .holder {
            width: 100 percent;
        }
    }
    </style>
        <style>
    .errorWrap {
    cushioning: 10px;
    edge: 0 0 20px 0;
    foundation: #fff;
    line left: 4px strong #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    cushioning: 10px;
    edge: 0 0 20px 0;
    foundation: #fff;
    line left: 4px strong #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>

</head>

<body>

<?php include('includes/header.php');?>

    <div class="container">

        <h1 class="mt-4 mb-3">Become a <small>Donor</small></h1>

        <old class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-thing active">Become a Donor</li>
        </ol>

            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php reverberation htmlentities($error); ?> </div><?php }
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php reverberation htmlentities($msg); ?> </div><?php }?>
        
        <structure name="donar" method="post">
<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Full Name<span style="color:red">*</span></div>
<div><input type="text" name="fullname" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-italic">Mobile Number<span style="color:red">*</span></div>
<div><input type="text" name="mobileno" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-italic">Email Id</div>
<div><input type="email" name="emailid" class="form-control"></div>
</div>
</div>

<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Age<span style="color:red">*</span></div>
<div><input type="text" name="age" class="form-control" required></div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Gender<span style="color:pink">*</span></div>
<div><select name="gender" class="form-control" required>
<choice value="">Select</option>
<choice value="Male">Male</option>
<choice value="Female">Female</option>
</select>
</div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Blood Group<span style="color:red">*</span> </div>
<div><select name="bloodgroup" class="form-control" required>
<?php $sql = "SELECT * from tblbloodgroup ";
$question = $dbh - > prepare($sql);
$inquiry >execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>
<choice value="<?php reverberation htmlentities($result->BloodGroup);?>"><?php reverberation htmlentities($result->BloodGroup);?></option>
<?php }} ?>
</select>
</div>
</div>
</div>

<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Address</div>
<div><textarea class="form-control" name="address"></textarea></div>
</div>

<div class="col-lg-8 mb-4">
<div class="font-italic">Message<span style="color:red">*</span></div>
<div><textarea class="form-control" name="message" required> </textarea></div>
</div>
</div>

<div class="row">
<div class="col-lg-4 mb-4">
<div><input type="submit" name="submit" class="btn btn-essential" value="Here is submit" style="cursor:pointer"></div>
</div>

</div>

</form>

</div>
  <?php include('includes/footer.php');?>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tie/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>