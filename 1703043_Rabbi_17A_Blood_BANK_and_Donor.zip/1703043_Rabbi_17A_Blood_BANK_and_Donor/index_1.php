<?php
error_reporting(0);//error_reporting(0); To remove all errors, warnings, parse messages, and notices
include('includes/config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BloodBank & Donor Management</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    .carousel-item.active,
    .carousel-item-next,
    .carousel-item-prev {
        display: block;
    }
    </style>

</head>

<body>

                                   
<?php include('includes/header.php');?>
<?php include('includes/slider.php');?>
   
                                    <!-- Page Content -->
    <div class="container">

        <h1 class="my-4">BloodBank & Donor Management</h1>

                                   
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <h4 class="card-header">The need for blood</h4>
                   
                        <p class="card-text" style="padding-left:2%">The love of pain is the major ecological concern, yet I allow this sort of time to tumble down, so that some tremendous anguish and suffering are experienced. </div>
            </div>
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <h4 class="card-header">Blood Tips</h4>
                   
                        <p class="card-text" style="padding-left:2%">Look up blood stocks on the internet. It's a good idea to check the blood stocks before your visit if you know your blood type.... drink enough of water.... take a salty snack.... dress comfortably.... avoid hard lifting and intense exercise.... share your good deed.</p>
                </div>
            </div>
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <h4 class="card-header">Who you could Help</h4>
                   
                        <p class="card-text" style="padding-left:2%">Blood donors serve patients of all ages every day, including accident and burn sufferers, heart surgery and organ transplant patients, and cancer patients</p>
                </div>
            </div>
        </div>
        
        <h2>Several Donars</h2>

        <div class="row">
                   <?php 
$status=1;
$sql = "SELECT * from tblblooddonars where status=:status order by rand() limit 6";
$query = $dbh -> prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR); //bindParam () function is used to pass variable not value.
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>

            <div class="col-lg-4 col-sm-6 portfolio-item">
                <div class="card h-100">
                    <a href="#"><img class="card-img-top img-fluid" src="images/pic4.jpg" alt="No image" ></a>
                    <div class="card-block">
                        <h4 class="card-title"><a href="#"><?php echo htmlentities($result->FullName);?></a></h4>
<p class="card-text"><b>  Gender :</b> <?php echo htmlentities($result->Gender);?></p>
<p class="card-text"><b>Blood Group :</b> <?php echo htmlentities($result->BloodGroup);?></p>

                    </div>
                </div>
            </div>

            <?php }} ?>
          
 



        </div>
                    
        <div class="row">
            <div class="col-lg-6">
                <h2>BLOOD GROUPS</h2>
          <p>  blood group of any human being will mainly fall in any one of the following groups.</p>
                <ul>
                
                
<li>A positive or A negative</li>
<li>B positive or B negative</li>
<li>O positive or O negative</li>
<li>AB positive or AB negative.</li>
                </ul>
                <p>A healthy diet helps ensure a successful blood donation, and also makes you feel better! Check out the following recommended foods to eat prior to your donation.</p>
            </div>
            <div class="col-lg-6">
                <img class="img-fluid rounded" src="images/pic__3.jpg" alt="">
            </div>
        </div>
       

        <hr>
        
        

        <div class="row mb-4">
            <div class="col-md-8">
            <h4>UNIVERSAL DONORS AND RECIPIENTS</h4>
                <p>
The most common blood type is O, followed by type A.

Type O individuals are often called "universal donors" since their blood can be transfused into persons with any blood type. Those with type AB blood are called "universal recipients" because they can receive blood of any type.</p>
            </div>
            <div class="col-md-4">
                <a class="btn btn-lg btn-secondary btn-block" href="become-donar.php">Become a Donar</a>
            </div>
        </div>

    </div>
    
    <p>Example Request: <a href="http://localhost/done/api/post/read_single.php?id=1">http://localhost/done/api/post/read_single.php</a></p>
    <p>Example Request: <a href="http://localhost/done/api/post/read.php">http://localhost/done/api/post/id=all/blood_donors</a></p>
    <div  style="width:100%">
                <div class="card">
                    <h4 class="card-header">Example response:</h4>
                   
                        <p class="card-text"><pre>{
    "data": [
        {
            "id": "1",
            "FullName": "Md Amir",
            "MobileNumber": "01640821914",
            "EmailId": "amir1122@gmail.com",
            "Gender": "male",
            "Age": "43",
            "BloodGroup": "A+",
            "Address": "Tangail",
            "Message": "Hello ,I want to donate blood",
            "PostingDate": "2021-02-01 23:19:19",
            "status": "1"
        },
        {
            "id": "2",
            "FullName": "Md Samir",
            "MobileNumber": "01640821915",
            "EmailId": "smir7122@gmail.com",
            "Gender": "male",
            "Age": "32",
            "BloodGroup": "B+",
            "Address": "Dhaka",
            "Message": "I want to donate blood",
            "PostingDate": "2021-02-02 00:19:19",
            "status": "1"
        },
        {
            "id": "3",
            "FullName": "Helena Khan",
            "MobileNumber": "01720821916",
            "EmailId": "helena3122@gmail.com",
            "Gender": "female",
            "Age": "29",
            "BloodGroup": "O+",
            "Address": "Jessor",
            "Message": "I want to donate blood",
            "PostingDate": "2021-02-02 01:19:19",
            "status": "1"
        },
        {
            "id": "4",
            "FullName": "Jim Mondol",
            "MobileNumber": "01640821917",
            "EmailId": "jim4422@gmail.com",
            "Gender": "male",
            "Age": "56",
            "BloodGroup": "AB+",
            "Address": "Khulna",
            "Message": "Hi,I want to donate blood",
            "PostingDate": "2021-02-02 02:19:19",
            "status": "1"
        },
        {
            "id": "5",
            "FullName": "Mrs Khobir Setu",
            "MobileNumber": "01640821919",
            "EmailId": "Khobir_12_bd@gmail.com",
            "Gender": "female",
            "Age": "25",
            "BloodGroup": "AB-",
            "Address": "Rajshahi",
            "Message": "Please, I want to donate blood",
            "PostingDate": "2021-02-02 03:19:19",
            "status": "1"
        },
        {
            "id": "6",
            "FullName": "Mr. Anik",
            "MobileNumber": "01718466314",
            "EmailId": "anik_student.com@gmail.com",
            "Gender": "Male",
            "Age": "24",
            "BloodGroup": "O-",
            "Address": "Khulna",
            "Message": " It's my pleasure to donate blood.",
            "PostingDate": "2021-07-24 00:32:48",
            "status": "1"
        },
        {
            "id": "7",
            "FullName": "Kangana Ranaut",
            "MobileNumber": "0164082291",
            "EmailId": "Kangana_Ranaut@gmail.com",
            "Gender": "Female",
            "Age": "21",
            "BloodGroup": "O+",
            "Address": "Tangail",
            "Message": " Donate",
            "PostingDate": "2021-08-01 10:55:11",
            "status": "1"
        },
        {
            "id": "11",
            "FullName": "Galib Titu",
            "MobileNumber": "01640821967",
            "EmailId": "galib1234@gmail.com",
            "Gender": "Male",
            "Age": "35",
            "BloodGroup": "AB-",
            "Address": "Jamalpur",
            "Message": "i want to donate blood.",
            "PostingDate": "2021-09-03 15:28:16",
            "status": "1"
        },
        {
            "id": "12",
            "FullName": "Mr. Siam",
            "MobileNumber": "01766662314",
            "EmailId": "sivm@gmail.com",
            "Gender": "Male",
            "Age": "32",
            "BloodGroup": "B+",
            "Address": "Mirpur",
            "Message": " I want to donate blood",
            "PostingDate": "2021-09-03 15:35:49",
            "status": "1"
        },
        {
            "id": "13",
            "FullName": "Sohanur Rahman",
            "MobileNumber": "01725795345",
            "EmailId": "sohan71@gmail.com",
            "Gender": "Male",
            "Age": "27",
            "BloodGroup": "O-",
            "Address": "Tangail",
            "Message": " I want to donate blood",
            "PostingDate": "2021-09-03 15:40:15",
            "status": "1"
        },
        {
            "id": "14",
            "FullName": "Fahim Muntasir",
            "MobileNumber": "01725795678",
            "EmailId": "fahim234@gmail.com",
            "Gender": "Male",
            "Age": "22",
            "BloodGroup": "AB+",
            "Address": "Rahimganj",
            "Message": " I want to donate blood",
            "PostingDate": "2021-09-03 15:43:32",
            "status": "1"
        },
        {
            "id": "15",
            "FullName": "Risalat Labib",
            "MobileNumber": "01725795278",
            "EmailId": "labib458@gmail.com",
            "Gender": "Male",
            "Age": "31",
            "BloodGroup": "O-",
            "Address": "Manikganj",
            "Message": " ",
            "PostingDate": "2021-09-03 15:52:07",
            "status": "1"
        },
        {
            "id": "16",
            "FullName": "Mrs. Hasi",
            "MobileNumber": "01640821389",
            "EmailId": "hasi_674@gmail.com",
            "Gender": "Female",
            "Age": "38",
            "BloodGroup": "O-",
            "Address": "Hobiganj",
            "Message": " I want to donate blood",
            "PostingDate": "2021-09-03 15:58:44",
            "status": "1"
        },
        {
            "id": "17",
            "FullName": "Aditi Roy",
            "MobileNumber": "0171848906",
            "EmailId": "aditi30@gmail.com",
            "Gender": "Female",
            "Age": "29",
            "BloodGroup": "B+",
            "Address": "Narayanganj",
            "Message": " I want to donate blood",
            "PostingDate": "2021-09-03 16:01:31",
            "status": "1"
        },
        {
            "id": "18",
            "FullName": "Ahana Khan",
            "MobileNumber": "0164082432",
            "EmailId": "khan@gmail.com",
            "Gender": "Female",
            "Age": "25",
            "BloodGroup": "AB-",
            "Address": "Rangpur",
            "Message": " I want to donate biood",
            "PostingDate": "2021-09-03 16:04:48",
            "status": "1"
        },
        {
            "id": "19",
            "FullName": "Ema Haque",
            "MobileNumber": "01718490078",
            "EmailId": "emma79@gmail.com",
            "Gender": "Female",
            "Age": "36",
            "BloodGroup": "B+",
            "Address": "Dhaka",
            "Message": " I want to donate blood",
            "PostingDate": "2021-09-03 16:09:30",
            "status": "1"
        },
        {
            "id": "20",
            "FullName": "Sara Sayyad",
            "MobileNumber": "01640830008",
            "EmailId": "sara@gmail.com",
            "Gender": "Female",
            "Age": "21",
            "BloodGroup": "O+",
            "Address": "Rajshahi",
            "Message": " I want to donate blood",
            "PostingDate": "2021-09-03 16:12:39",
            "status": "1"
        },
        {
            "id": "21",
            "FullName": "Arifin Ikram",
            "MobileNumber": "01718468790",
            "EmailId": "arifin@gmail.com",
            "Gender": "Male",
            "Age": "28",
            "BloodGroup": "AB-",
            "Address": "Bhuapur",
            "Message": "I want to donate blood ",
            "PostingDate": "2021-09-03 16:15:38",
            "status": "1"
        },
        {
            "id": "22",
            "FullName": "Raju Mia",
            "MobileNumber": "01718466317",
            "EmailId": "mia97@gmail.com",
            "Gender": "Male",
            "Age": "24",
            "BloodGroup": "B+",
            "Address": "Khulna",
            "Message": " I want to donate blood",
            "PostingDate": "2021-09-03 16:17:44",
            "status": "1"
        }
    ]
} </pre>
</div>
            </div><hr>
    

  <?php include('includes/footer.php');?>

  
    <script src="vendor/jquery/jquery.min.js"></script>




    <script src="vendor/tether/tether.min.js"></script>




      <script src="vendor/bootstrap/js/bootstrap.min.js"></script> 

</body>

</html>
