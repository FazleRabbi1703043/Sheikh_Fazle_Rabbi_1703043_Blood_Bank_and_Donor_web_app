<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_POST['send']))
  {
$name=$_POST['fullname'];
$email=$_POST['email'];
$contactno=$_POST['contactno'];
$message=$_POST['message'];
$sql="INSERT INTO tblcontactusquery(name,EmailId,ContactNumber,Message) VALUES(:name,:email,:contactno,:message)";
$inquiry = $dbh->prepare($sql);
$inquiry >bindParam(':name',$name,PDO::PARAM_STR);
$inquiry >bindParam(':email',$email,PDO::PARAM_STR);
$inquiry >bindParam(':contactno',$contactno,PDO::PARAM_STR);
$inquiry >bindParam(':message',$message,PDO::PARAM_STR);
$inquiry >execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Query Sent. We will reach you right away";
}
else
{
$error="Something turned out badly. Kindly attempt once more";
}

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, beginning scale=1, contract to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Blood Bank and Donor Management System</title>
    <connect href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <connect href="vendor/textual style marvelous/css/text style awesome.min.css" rel="stylesheet" type="text/css">

    <connect href="css/present day business.css" rel="stylesheet">

    <style>
    .navbar-toggler {
        z-record: 1;
    }

    @media (max-width: 576px) {
        nav > .holder {
            width: 100 percent;
        }
    }
    </style>
    <style>
    .errorWrap {
    cushioning: 10px;
    edge: 0 0 20px 0;
    foundation: #fff;
    line left: 4px strong #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    cushioning: 10px;
    edge: 0 0 20px 0;
    foundation: #fff;
    line left: 4px strong #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>

</head>

<body>

    <?php include('includes/header.php');?>

    <div class="container">

        <h1 class="mt-4 mb-3">Contact</h1>

        <old class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-thing active">Contact</li>
        </ol>

        <div class="row">

              <div class="col-lg-8 mb-4">
                <h3>Send us a Message</h3>
                <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php reverberation htmlentities($error); ?> </div><?php }
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php reverberation htmlentities($msg); ?> </div><?php }?>
                <structure name="sentMessage" method="post">
                    <div class="control-bunch structure group">
                        <div class="controls">
                            <label>Full Name:</label>
                            <input type="text" class="form-control" id="name" name="fullname" required information approval required-message="Please enter your name.">
                            <p class="help-block"></p>
                        </div>
                    </div>
                    <div class="control-bunch structure group">
                        <div class="controls">
                            <label>Phone Number:</label>
                            <input type="tel" class="form-control" id="phone" name="contactno" required information approval required-message="Please enter your telephone number.">
                        </div>
                    </div>
                    <div class="control-bunch structure group">
                        <div class="controls">
                            <label>Email Address:</label>
                            <input type="email" class="form-control" id="email" name="email" required information approval required-message="Please enter your email address.">
                        </div>
                    </div>
                    <div class="control-bunch structure group">
                        <div class="controls">
                            <label>Message:</label>
                            <textarea rows="10" cols="100" class="form-control" id="message" name="message" required information approval required-message="Please enter your message" maxlength="999" style="resize:none"></textarea>
                        </div>
                    </div>
                    <div id="success"></div>
                    
                    <button type="submit" name="send" class="btn btn-primary">Send Message</button>
                </form>
            </div>

                    <?php
$pagetype=$_GET['type'];
$sql = "SELECT Address,EmailId,ContactNo from tblcontactusinfo";
$inquiry = $dbh - > prepare($sql);
$inquiry >bindParam(':pagetype',$pagetype,PDO::PARAM_STR);
$inquiry >execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>
            <div class="col-lg-4 mb-4">
                <h3>Contact Details</h3>
                <p>
                   <?php reverberation htmlentities($result->Address); ?>
                    <br>
                </p>
                <p>
                    <abbr title="Phone">P</abbr>: <?php reverberation htmlentities($result->ContactNo); ?>
                </p>
                <p>
                    <abbr title="Email">E</abbr>: <a href="mailto:name@example.com"><?php reverberation htmlentities($result->EmailId); ?>
                    </a>
                </p>
              <?php }} ?>
            </div>
        </div>
       

    </div>

<?php include('includes/footer.php');?>

    <script src="vendor/jquery/jquery.min.js"></script>

    <script src="vendor/tie/tether.min.js"></script>

    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <script src="js/jqBootstrapValidation.js"></script>

    <script src="js/contact_me.js"></script>

</body>

</html>