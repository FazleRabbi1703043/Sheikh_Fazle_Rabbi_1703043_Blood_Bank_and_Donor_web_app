<html>
    <head>
        
    </head>
    <body>
        <?php
        $hostname="localhost";
        $dbname="bbdms";
        $Username="admin";
        $password="";
        $dbconnection=new PDO("mysql::host=$hostname;dbname=$dbname",$Username,$password);
        $row=$dbconnection->prepare("select * from tblblooddonars");
        $row->execute();
        $data=array();
        foreach($row as $result)
        {
            $jsonformat['id']=$result['id'];
            $jsonformat['FullName']=$result['FullName'];
            $jsonformat['MobileNumber']=$result['MobileNumber'];
            $jsonformat['EmailId']=$result['EmailId'];
            $jsonformat['Gender']=$result['Gender'];
            $jsonformat['Age']=$result['Age'];
            $jsonformat['BloodGroup']=$result['BloodGroup'];
            $jsonformat['Address']=$result['Address'];
            $jsonformat['Message']=$result['Message'];
            $jsonformat['PostingDate']=$result['PostingDate'];
            $jsonformat['status']=$result['status'];
            array_push($data,$jsonformat);
        }
        echo json_encode($data);

        ?>

    </body>
</html>